
How to Run This Dashboard
=========================

1. Extract the `.zip` file to a local directory  
   For example:
   C:/Users/YourName/Documents/FireStationProject/

2. Make sure the `/data/` folder stays in the SAME directory as the `.pbix` file:

   /FireStationProject/
   ├── Visualization_Team_139.pbix
   └── /data/
       ├── Potential_location.csv
       ├── .....

3. Open `Visualization_Team_139.pbix` in Power BI Desktop

4. Power BI may prompt you to enable Python visuals — click ENABLE

5. Set up your Python environment if needed:
   - Go to: File → Options and settings → Options → Python scripting
   - Set the correct Python path (e.g., from Anaconda or a local install)

6. Use the slicers on the right side of the report to adjust:
   - Low / Medium / High coverage weightages
   - Number of fire station locations

7. Wait ~4–5 minutes for the Python optimization script to run.
   - The output map will display the selected optimal locations in a browser window.
   - A confirmation message will also be shown in Power BI.

